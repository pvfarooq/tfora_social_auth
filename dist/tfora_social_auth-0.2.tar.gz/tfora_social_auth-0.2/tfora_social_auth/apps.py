from django.apps import AppConfig


class SocialAuthFarooqConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tfora_social_auth'
